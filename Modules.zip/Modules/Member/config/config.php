<?php

return [
    'name' => 'Member',
];
