<?php

namespace Modules\Member\App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MemberRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'name' => 'required',
            'email' => ['required', 'email'],
            'password' => ['required', 'min:8'],
            'image' => ['required'],
            'address' => ['required'],
            'phone' => ['required'],
            'type' => 'required|string|in:member,caregiver,partner,volunteer,donor',
            'age' => 'required_if:type,member|integer',
            'health_condition' => 'required_if:type,member|string',
            'dietary_requirements' => 'required_if:type,member|string',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    // public function authorize(): bool
    // {
    //     return true;
    // }
}
