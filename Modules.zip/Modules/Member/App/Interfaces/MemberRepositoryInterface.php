<?php

namespace Modules\Member\App\Interfaces;

interface MemberRepositoryInterface{
    public function storeMember($validatedData);
}
