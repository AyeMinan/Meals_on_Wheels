<?php

namespace Modules\Member\Repositories;

use App\Models\Member;
use App\Models\Profile;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Modules\Member\App\Interfaces\MemberRepositoryInterface;

class MemberRepository implements MemberRepositoryInterface
{
    public function storeMember($validatedData){


            try{
            DB::beginTransaction();
            $user = User::create([
                'name' => $validatedData['name'],
                'email' => $validatedData['email'],
                'password' => Hash::make($validatedData['password']),
                'type' => $validatedData['type'],
            ]);

            // Create a profile instance
            $profile = new Profile([
                'image' => $validatedData['image'],
                'name' => $validatedData['name'],
                'address' => $validatedData['address'],
                'phone' => $validatedData['phone'],
            ]);

            // Associate the profile with the user
            $user->profile()->save($profile);

            if ($validatedData['type'] === 'member') {
                $member = new Member([
                    'age' =>$validatedData['age'],
                    'health_condition' => $validatedData['health_condition'],
                    'dietary_requirements' => $validatedData['dietary_requirements'],
                ]);

                $user->member()->save($member);

            }

        }catch (\Throwable $th){
            DB::rollBack();
            throw new Exception($th->getmessage());
        }

    }
}
